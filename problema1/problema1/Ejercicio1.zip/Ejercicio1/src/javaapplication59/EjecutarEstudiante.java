/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication59;

/**
 *
 * @author KEVIN
 */
public class EjecutarEstudiante {

    public static void main(String[] args) {
        Notas uno = new Notas("Carlos", 7.7, 8.9, 9.1);
        
        System.out.println("-------- DATOS --------");
        System.out.println(uno.toString());
    }
    
}
