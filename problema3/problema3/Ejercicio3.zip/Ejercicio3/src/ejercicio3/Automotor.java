/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio3;

/**
 *
 * @author KEVIN
 */
public class Automotor {
    private String cedulaPropietario;
    private String marcaVehiculo;
    private int anio;
    private int valorVehiculo;
    

    public Automotor(String cedulaPropietario, String marcaVehiculo, int anio, int valorVehiculo) {
        this.cedulaPropietario = cedulaPropietario;
        this.marcaVehiculo = marcaVehiculo;
        this.anio = anio;
        this.valorVehiculo = valorVehiculo;
    }
    
    
    public String toString(){
        return "Cdeula del Propietario: " + cedulaPropietario + "\n" +
               "Marca: " + marcaVehiculo + "\n" +
               "Año de fabricacion: " + anio + "\n" +
               "Valor del vehiculo: " + valorVehiculo + "\n" +
               "Valor total de la matricula: " + calcularMatricula();        
    }
    
    public double calcularMatricula(){
        int antiguedad = 2024 - anio;
        return 0.002 * valorVehiculo * antiguedad;
    }
}
