
package ejercicio3;

/**
 *
 * @author KEVIN
 */
public class Ejercicio3 {

    public static void main(String[] args) {
        Automotor uno = new Automotor("1104789345", "Chevrolet", 2018, 15000);
        
        
        System.out.println("----- DATOS -----");
        System.out.println(uno.toString());
    }
    
}
