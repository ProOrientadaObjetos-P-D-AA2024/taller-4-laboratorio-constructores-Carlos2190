
package ejercicio2;

/**
 *
 * @author KEVIN
 */
public class Ejercicio2 {

    
    public static void main(String[] args) {
        Profesores uno = new Profesores("Wayner", "Bustamante", 1200, "1108935290");
        
        System.out.println("-------- DATOS --------");
        System.out.println(uno.toString());
    }
    
}
