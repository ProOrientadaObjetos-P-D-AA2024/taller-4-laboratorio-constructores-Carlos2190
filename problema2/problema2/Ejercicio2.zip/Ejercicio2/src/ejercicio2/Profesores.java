/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;

/**
 *
 * @author KEVIN
 */
public class Profesores {
    private String nombre;
    private String apellido;
    private double sueldoBasico;
    private double sueldoTotal;
    private String cedula;

    public Profesores(String nombre, String apellido, double sueldoBasico, String cedula) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.sueldoBasico = sueldoBasico;
        this.cedula = cedula;
    }

    public String toString(){
        return "Nombre: " + nombre + "\n" +
               "Apellido: " + apellido + "\n" +
               "Cedula: " + cedula + "\n" +
               "Sueldo Basico: " + sueldoBasico + "\n" +
               "Total del sueldo con el 20%: " + calcularSueldoTotal();
                
        
    }
    
    public double calcularSueldoTotal(){
        return (sueldoBasico * 1.2);
    }
}
