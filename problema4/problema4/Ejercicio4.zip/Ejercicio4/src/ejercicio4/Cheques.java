/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author KEVIN
 */
public class Cheques {
    private String nombreCliente;
    private String nombreBanco;
    private double valorCheque;
    private double comisionBanco;

    public Cheques(String nombreCliente, String nombreBanco, double valorCheque) {
        this.nombreCliente = nombreCliente;
        this.nombreBanco = nombreBanco;
        this.valorCheque = valorCheque;
    }
    
    public double calcularComision(){
        return 0.003 * valorCheque;
    }
    
    public String toString(){
      return "Nombre del Cliente: " + nombreCliente + "\n" +
             "Nombre del Banco: " + nombreBanco + "\n" +
             "Valor cheque: " + valorCheque + "\n" +
             "Valor de la comision del banco: " + calcularComision();
    }
    
    
}
