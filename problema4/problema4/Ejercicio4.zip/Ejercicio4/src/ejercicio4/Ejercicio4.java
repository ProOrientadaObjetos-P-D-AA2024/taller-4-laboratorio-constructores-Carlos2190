
package ejercicio4;

/**
 *
 * @author KEVIN
 */
public class Ejercicio4 {

    
    public static void main(String[] args) {
        Cheques uno = new Cheques("Flavio", "Banco de Loja", 5000);
        
        System.out.println("------- DATOS -------");
        System.out.println(uno.toString());
    }
    
}
